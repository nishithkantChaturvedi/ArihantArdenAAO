<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Gallery – Arihant Arden AOA</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">

  <style>
    :root {
      --primary-color: #2e7d32;
      --secondary-color: #81c784;
      --bg-gradient: linear-gradient(to right, #e8f5e9, #c8e6c9);
      --text-color: #2e2e2e;
    }

    body {
      margin: 0;
      font-family: 'Poppins', sans-serif;
      background: var(--bg-gradient);
      color: var(--text-color);
    }

    header {
      display: flex;
      align-items: center;
      justify-content: flex-start;
      padding: 30px 40px;
      background: linear-gradient(to right, #66bb6a, #43a047);
      color: #fff;
      flex-wrap: wrap;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    }

    header img {
      height: 80px;
      margin-right: 20px;
    }

    header .info {
      text-align: left;
    }

    header .info h1 {
      margin: 0 0 10px;
      font-size: 28px;
    }

    header .info p {
      margin: 5px 0;
      font-size: 15px;
    }

    header .info a {
      color: #fff;
      text-decoration: underline;
    }

    nav {
      display: flex;
      justify-content: center;
      background: #ffffff;
      padding: 15px 20px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    }

    nav a {
      margin: 0 15px;
      text-decoration: none;
      color: var(--primary-color);
      font-weight: 500;
      transition: color 0.3s ease, transform 0.2s ease;
    }

    nav a:hover {
      color: #1b5e20;
      transform: translateY(-2px);
    }

    .gallery {
      max-width: 1200px;
      margin: 40px auto;
      padding: 0 20px;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 20px;
    }

    .gallery img {
      width: 100%;
      height: 250px;
      object-fit: cover;
      border-radius: 12px;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .gallery img:hover {
      transform: scale(1.03);
      box-shadow: 0 12px 25px rgba(0, 0, 0, 0.15);
    }

    footer {
      text-align: center;
      padding: 20px;
      background-color: #f4f4f4;
      color: #555;
      font-size: 14px;
      margin-top: 50px;
      box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.05);
    }

    @media (max-width: 768px) {
      header {
        flex-direction: column;
        text-align: center;
        align-items: center;
      }

      header .info {
        text-align: center;
      }

      nav {
        flex-direction: column;
      }

      nav a {
        margin: 10px 0;
      }
    }
  </style>
</head>

<body>

  <header>
    <img src="untitled.png" alt="Arihant Arden Logo">
    <div class="info">
      <h1>Arihant Arden Association of Apartment Owners</h1>
      <p>Plot No GH-07A, Sector 1, Greater Noida West</p>
      <p>Phone: +91 (0) 120 5145800 | Email:
        <a href="mailto:admin@arihantardenaoa.org">admin@arihantardenaoa.org</a>
      </p>
    </div>
  </header>

  <nav>
    <a href="default.asp">Home</a>
    <a href="html_about.asp">About</a>
    <a href="html_gallery.asp">Gallery</a>
  <a href="tender.html">Tenders</a>
    <a href="achievements.asp">Achievements</a>
  </nav>

  <div class="gallery">
    <img src="ArihantArden2.jpg" alt="Arihant Arden 2">
    <img src="arden2.jpeg" alt="Arihant Arden 3">
    <img src="ArihantArden4.jpg" alt="Arihant Arden 4">
    <img src="arden4.jpeg" alt="Arihant Arden 5">
    <img src="ArihantArden6.jpg" alt="Arihant Arden 6">
    <img src="arden3.jpeg" alt="Arihant Arden 7">
    <img src="ArihantArden8.jpg" alt="Arihant Arden 8">
    <img src="ArihantArden9.jpg" alt="Arihant Arden 9">
  <img src="arden5.jpeg" alt="Arihant Arden 9">
  </div>

  <footer>
    &copy; 2025 Arihant Arden AOA. All rights reserved.
  </footer>

</body>
</html>
