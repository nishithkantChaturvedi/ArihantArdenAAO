<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>About Us – Arihant Arden AOA</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">

  <style>
    :root {
      --primary-color: #2e7d32;
      --secondary-color: #81c784;
      --bg-gradient: linear-gradient(to right, #e8f5e9, #c8e6c9);
      --text-color: #2e2e2e;
    }

    body {
      margin: 0;
      font-family: 'Poppins', sans-serif;
      background: var(--bg-gradient);
      color: var(--text-color);
    }

    header {
      display: flex;
      align-items: center;
      justify-content: flex-start;
      padding: 30px 40px;
      background: linear-gradient(to right, #66bb6a, #43a047);
      color: #fff;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
      flex-wrap: wrap;
    }

    header img {
      height: 80px;
      margin-right: 20px;
    }

    header .info {
      text-align: left;
    }

    header .info h1 {
      margin: 0 0 10px;
      font-size: 28px;
    }

    header .info p {
      margin: 5px 0;
      font-size: 15px;
    }

    header .info a {
      color: #fff;
      text-decoration: underline;
    }

    nav {
      display: flex;
      justify-content: center;
      background: #ffffff;
      padding: 15px 20px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    }

    nav a {
      margin: 0 15px;
      text-decoration: none;
      color: var(--primary-color);
      font-weight: 500;
      transition: color 0.3s ease, transform 0.2s ease;
    }

    nav a:hover {
      color: #1b5e20;
      transform: translateY(-2px);
    }

    .container {
      max-width: 900px;
      margin: 40px auto;
      padding: 0 20px;
      background: #ffffffdd;
      border-radius: 12px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
    }

    .container h2 {
      font-size: 24px;
      color: var(--primary-color);
      margin-top: 30px;
    }

    .container p {
      font-size: 16px;
      line-height: 1.7;
      margin-top: 10px;
    }

    footer {
      text-align: center;
      padding: 20px;
      background-color: #f4f4f4;
      color: #555;
      font-size: 14px;
      margin-top: 50px;
      box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.05);
    }

    @media (max-width: 768px) {
      header {
        flex-direction: column;
        text-align: center;
        align-items: center;
      }

      header .info {
        text-align: center;
      }

      nav {
        flex-direction: column;
      }

      nav a {
        margin: 10px 0;
      }
    }
  </style>
</head>

<body>

  <header>
    <img src="untitled.png" alt="Arihant Arden Logo">
    <div class="info">
      <h1>Arihant Arden Association of Apartment Owners</h1>
      <p>Plot No GH-07A, Sector 1, Greater Noida West</p>
      <p>Phone: +91 (0) 120 5145800 | Email: 
        <a href="mailto:admin@arihantardenaoa.org">admin@arihantardenaoa.org</a>
      </p>
    </div>
  </header>
  <nav>
    <a href="default.asp">Home</a>
    <a href="html_about.asp">About</a>
    <a href="html_gallery.asp">Gallery</a>
    <a href="tender.html">Tenders</a>
    <a href="achievements.asp">Achievements</a>
  </nav>

  <div class="container">
    <h2>Welcome to Arihant Arden AOA</h2>
    <p>
      We are a dedicated Apartment Owners Association committed to building a better, more joyful living experience for our residents. With the support of our community members, dedicated staff, and trusted service partners, we organize fundraising drives, cultural celebrations, and community events that bring people together and enhance everyday life.
    </p>

    <h2>Thank You</h2>
    <p>
      Your involvement — whether through volunteering, participating in events, or simply spreading the word — makes a meaningful impact. We are deeply grateful for your continued support in helping us reach our shared goals.
    </p>

    <h2>Get Involved</h2>
    <p>
      Passionate about making a difference in your community? We welcome volunteers to join our initiatives. Let us know your interests and availability, and we’ll help match you with the perfect opportunity. We’re excited to have you on board!
    </p>
  </div>

  <footer>
    &copy; 2025 Arihant Arden AOA. All rights reserved.
  </footer>

</body>
</html>
