<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Navratri 2025 Financial Dashboard | Arihant Arden AAO</title>
  <meta name="description" content="Navratri 2025 Financial Report – Arihant Arden Apartment Owners Association"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
  <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>

  <style>
    :root {
      --primary: #2e7d32;
      --bg: linear-gradient(to right, #e8f5e9, #c8e6c9);
      --accent: #43a047;
      --white: #fff;
      --shadow: rgba(0, 0, 0, 0.1);
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font: 16px/1.6 'Poppins', sans-serif;
      background: var(--bg);
      color: #333;
    }

    header {
      background: var(--accent);
      color: var(--white);
      box-shadow: 0 4px 15px var(--shadow);
      display: flex;
      align-items: center;
      padding: 1.5rem;
      flex-wrap: wrap;
    }

    header img {
      height: 80px;
      margin-right: 1rem;
    }

    header .info a {
      color: var(--white);
      text-decoration: underline;
    }

    nav {
      background: var(--white);
      box-shadow: 0 2px 8px var(--shadow);
      display: flex;
      justify-content: center;
      gap: 1rem;
      padding: .8rem;
    }

    nav a {
      color: var(--primary);
      font-weight: 500;
      text-decoration: none;
      transition: 0.3s;
    }

    nav a:hover {
      color: black;
      transform: translateY(-2px);
    }

    main {
      max-width: 1000px;
      margin: 2rem auto;
      padding: 0 1rem;
    }

    .container {
      background: var(--white);
      border-radius: 12px;
      box-shadow: 0 6px 18px var(--shadow);
      padding: 2rem;
      margin-bottom: 2rem;
    }

    h2 {
      text-align: center;
      color: var(--primary);
      margin-bottom: 15px;
    }

    p.intro {
      text-align: center;
      max-width: 800px;
      margin: 0 auto 30px;
      font-size: 16px;
    }

    .summary-box {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 1.5rem;
      margin-bottom: 30px;
    }

    .summary-card {
      background: #f7fdf7;
      border-left: 6px solid var(--primary);
      border-radius: 10px;
      padding: 1rem 1.5rem;
      min-width: 250px;
      text-align: center;
      box-shadow: 0 4px 12px rgba(0,0,0,0.05);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .summary-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 6px 18px rgba(0,0,0,0.1);
    }

    .summary-card h3 {
      color: var(--primary);
      margin-bottom: .4rem;
      font-size: 1.1rem;
    }

    .summary-card p {
      font-size: 1.4rem;
      font-weight: 600;
      color: #1b5e20;
    }

    .chart-container {
      display: grid;
height: 600px;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 30px;
      margin-top: 10px;
    }

    .chart-box {
      background: #f7fdf7;
      border-radius: 12px;
height: 300px;
      padding: 20px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.08);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .chart-box:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 20px rgba(0,0,0,0.12);
    }

    .download-btn {
      display: block;
      width: fit-content;
      margin: 40px auto 10px;
      background: var(--accent);
      color: #fff;
      text-align: center;
      padding: 12px 25px;
      border-radius: 8px;
      text-decoration: none;
      font-weight: 600;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      transition: 0.3s;
    }

    .download-btn:hover {
      background: #2e7d32;
      transform: scale(1.05);
    }

    @media (max-width: 768px) {
      header { justify-content: center; text-align: center; }
      nav { flex-direction: column; }
      .summary-card { min-width: 200px; }
    }
  </style>
</head>

<body>
  <header>
    <img src="untitled.png" alt="Arihant Arden Logo"/>
    <div class="info">
      <h1>Arihant Arden Association of Apartment Owners</h1>
      <p>Plot No GH-07A, Sector 1, Greater Noida West</p>
      <p>📞 +91 120 5145800 • ✉️ <a href="mailto:admin@arihantardenaoa.org">admin@arihantardenaoa.org</a></p>
    </div>
  </header>

  <nav>
    <a href="default.asp">Home</a>
    <a href="html_about.asp">About</a>
    <a href="html_gallery.asp">Gallery</a>
    <a href="tender.asp">Tender</a>
    <a href="achievements.asp">Achievements</a>
    <a href="data-sharing.asp" style="color:black;font-weight:600;">Information Board</a>
  </nav>

  <main>
    <div class="container">
      <h2>Navratri 2025 Collection & Expense Report</h2>
      <p class="intro">
        The following summary presents the collections and expenses from the Navratri 2025 celebrations,
        highlighting contributions and costs related to both Pooja and Cultural events. This dashboard
        reflects Arihant Arden AAO’s continued commitment to transparency and community engagement.
      </p>

      <div class="summary-box">
        <div class="summary-card">
          <h3>Total Collection</h3>
          <p>₹6,96,064</p>
        </div>
        <div class="summary-card">
          <h3>Total Expenses</h3>
          <p>₹5,42,512</p>
        </div>
        <div class="summary-card">
          <h3>Final Balance</h3>
          <p>₹1,53,552</p>
        </div>
      </div>

      <div class="chart-container">
        <div class="chart-box" id="collectionSplit"></div>
        <div class="chart-box" id="expenseSplit"></div>
        <div class="chart-box" id="overallSummary"></div>
      </div>

      <a class="download-btn" id="downloadCSV">⬇️ Download Financial Summary (CSV)</a>
    </div>
  </main>

  <script>
    const poojaCollection = 563064;
    const culturalCollection = 133000;
    const poojaExpense = 444287;
    const culturalExpense = 98225;
    const totalCollection = poojaCollection + culturalCollection;
    const totalExpense = poojaExpense + culturalExpense;
    const totalBalance = totalCollection - totalExpense;

    // Chart 1
    Plotly.newPlot('collectionSplit', [{
      values: [poojaCollection, culturalCollection],
      labels: ['Pooja Collection', 'Cultural Collection'],
      type: 'pie',
      textinfo: 'label+percent',
      marker: { colors: ['#66bb6a', '#43a047'] }
    }], { title: 'Collection Split: Pooja vs Cultural' });

    // Chart 2
    Plotly.newPlot('expenseSplit', [{
      x: ['Pooja Expenses', 'Cultural Expenses'],
      y: [poojaExpense, culturalExpense],
      type: 'bar',
      marker: { color: ['#81c784', '#66bb6a'] }
    }], { title: 'Expense Breakdown by Category', yaxis: { title: 'Amount (₹)' } });

    // Chart 3
    Plotly.newPlot('overallSummary', [{
      x: ['Total Collection', 'Total Expense', 'Balance'],
      y: [totalCollection, totalExpense, totalBalance],
      type: 'bar',
      marker: { color: ['#2e7d32', '#e53935', '#388e3c'] }
    }], { title: 'Overall Financial Summary', yaxis: { title: 'Amount (₹)' } });

    // CSV Download
    document.getElementById('downloadCSV').addEventListener('click', () => {
      const rows = [
        ['Description', 'Amount (₹)'],
        ['Pooja Collection', poojaCollection],
        ['Cultural Collection', culturalCollection],
        ['Total Collection', totalCollection],
        ['Pooja Expenses', poojaExpense],
        ['Cultural Expenses', culturalExpense],
        ['Total Expenses', totalExpense],
        ['Overall Balance', totalBalance]
      ];
      let csvContent = 'data:text/csv;charset=utf-8,' + rows.map(e => e.join(',')).join('\\n');
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement('a');
      link.setAttribute('href', encodedUri);
      link.setAttribute('download', 'Navratri2025_Financial_Summary.csv');
      document.body.appendChild(link);
      link.click();
    });
  </script>
</body>
</html>
