<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Arihant Arden AAO</title>
  <meta name="description" content="Arihant Arden AAO – Association of Apartment Owners, Greater Noida West"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">

  <style>
    :root {
      --primary: #2e7d32;
      --bg: linear-gradient(to right, #e8f5e9, #c8e6c9);
      --accent: #43a047;
      --white: #fff;
      --shadow: rgba(0, 0, 0, 0.1);
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font: 16px/1.6 'Poppins', sans-serif;
      background: var(--bg);
      color: #333;
    }

    header {
      background: var(--accent);
      color: var(--white);
      box-shadow: 0 4px 15px var(--shadow);
      display: flex;
      align-items: center;
      padding: 1.5rem;
      flex-wrap: wrap;
    }

    header img {
      height: 80px;
      margin-right: 1rem;
    }

    header .info a {
      color: var(--white);
      text-decoration: underline;
    }

    nav {
      background: var(--white);
      box-shadow: 0 2px 8px var(--shadow);
      display: flex;
      justify-content: center;
      gap: 1rem;
      padding: .8rem;
    }

    nav a {
      color: var(--primary);
      font-weight: 500;
      text-decoration: none;
      transition: 0.3s;
    }

    nav a:hover {
      color: black;
      transform: translateY(-2px);
    }

    main {
      max-width: 1000px;
      margin: 2rem auto;
      padding: 0 1rem;
    }

    .hero {
      width: 100%;
      border-radius: 12px;
      box-shadow: 0 6px 20px var(--shadow);
      transition: .3s ease;
      margin-top: 2rem;
    }

    .hero:hover {
      transform: scale(1.02);
    }

    .container {
      background: var(--white);
      border-radius: 12px;
      box-shadow: 0 6px 18px var(--shadow);
      margin-bottom: 2rem;
      padding: 2rem;
    }


    @media (max-width: 768px) {
      header {
        justify-content: center;
        text-align: center;
      }

      nav {
        flex-direction: column;
      }
    }
  </style>
</head>

<body>
  <header>
    <img src="untitled.png" alt="Arihant Arden Logo"/>
    <div class="info">
      <h1>Arihant Arden Association of Apartment Owners</h1>
      <p>Plot No GH‑07A, Sector 1, Greater Noida West</p>
      <p>📞 +91 120 5145800 • ✉️ <a href="mailto:admin@arihantardenaoa.org">admin@arihantardenaoa.org</a></p>
    </div>
  </header>

  <nav>
    <a href="default.asp">Home</a>
    <a href="html_about.asp">About</a>
    <a href="html_gallery.asp">Gallery</a>
  <a href="tender.html">Tenders</a>
    <a href="achievements.asp">Achievements</a>
  <a href="info-sharing.html">Information Board</a>
  </nav> 

  <main>
    <div class="container">
      <!-- AAO Board Section Start -->
<style>
  .aao-board-section {
    background: #f7fdf7;
    padding: 30px;
    border-radius: 12px;
    margin: 30px auto;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
    max-width: 900px;
    font-family: 'Segoe UI', sans-serif;
    color: #333;
  }

  .aao-board-section h2 {
    font-size: 24px;
    margin-bottom: 15px;
    color: #1a5f1a;
  }

  .aao-board-section p {
    line-height: 1.7;
    margin-bottom: 15px;
    font-size: 16px;
  }

  .aao-board-section ul {
    list-style-type: disc;
    margin-left: 20px;
    margin-bottom: 15px;
  }

  .aao-board-section ul li {
    margin-bottom: 8px;
    font-size: 16px;
  }

  .aao-board-image {
    margin-top: 25px;
    border-radius: 10px;
    width: 100%;
    max-width: 100%;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  }
</style>

<div class="aao-board-section">
  <h2><strong>New AAO Board – 2025</strong></h2>

  <p>
    We are pleased to introduce the newly elected board of the 
    <strong>Arihant Arden Apartment Owners Association</strong> for the year <strong>2025</strong>. 
    This team is committed to improving the quality of life for all residents by ensuring 
    <em>transparency, safety, and community development</em>.
  </p>

  <p>
    The board is led by <strong>Nishith Kant Chaturvedi</strong> as <strong>President</strong>, 
    supported by:
  </p>

  <ul>
    <li><strong>R K Posh</strong> – <em>Vice President</em></li>
    <li><strong>Lokesh Tyagi</strong> – <em>Secretary</em></li>
    <li><strong>Ashok K Singh</strong> – <em>Treasurer</em></li>
    <li><strong>Ravi Shanker</strong> – <em>Joint Secretary</em></li>
    <li><strong>Priyanka Jain</strong> – <em>Joint Treasurer</em></li>
  </ul>

  <p>
    Our Executive Members include: 
    <strong>N K Singh</strong>, 
    <strong>Satyam Srivastava</strong>, 
    <strong>Sanjay Chaudhary</strong>, and 
    <strong>Varun Girdhar</strong>.
  </p>

  <p>
    We look forward to working together with the entire community to make 
    <strong>Arihant Arden</strong> a model of cooperative living.
  </p>

   <img src="team_2025_nishith.jpg" alt="AAO Team 2025" class="hero" id="team-image"/>
</div>
<!-- AAO Board Section End --> 
   
    </div>
  </main>

</body>
</html>
