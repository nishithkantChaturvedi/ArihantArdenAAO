<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Arihant Arden AAO</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      background-color: #f2f2f2;
      color: #333;
    }

    header {
      display: flex;
      align-items: center;
      background-color: #e8f5e9;
      padding: 20px;
    }

    header img {
      height: 80px;
      margin-right: 20px;
    }

    header .info h1 {
      margin: 0;
      font-size: 24px;
      color: #2e7d32;
    }

    nav {
      background-color: #f1f1f1;
      padding: 10px 20px;
    }

    nav a {
      margin-right: 30px;
      text-decoration: none;
      color: #2e7d32;
      font-weight: bold;
    }

    .hero-image {
      width: 100%;
      max-width: 1200px;
      height: auto;
      display: block;
      margin: 20px auto;
      border-radius: 8px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    .carousel {
      position: relative;
      max-width: 1000px;
      margin: 40px auto;
      overflow: hidden;
      border-radius: 10px;
    }

    .slides {
      display: flex;
      transition: transform 0.5s ease-in-out;
      width: 300%;
    }

    .slide {
      min-width: 100%;
      transition: opacity 0.5s ease-in-out;
    }

    .slide img {
      width: 100%;
      display: block;
    }

    .carousel-buttons {
      position: absolute;
      top: 50%;
      width: 100%;
      display: flex;
      justify-content: space-between;
      transform: translateY(-50%);
    }

    .carousel-buttons button {
      background-color: rgba(0,0,0,0.4);
      border: none;
      color: white;
      font-size: 24px;
      padding: 10px 20px;
      cursor: pointer;
    }

    @media (max-width: 768px) {
      header {
        flex-direction: column;
        text-align: center;
      }

      header img {
        margin: 0 0 10px 0;
      }

      nav a {
        display: block;
        margin: 10px 0;
      }
    }
  </style>
</head>

<body>

  <header>
    <img src="untitled.png" alt="Arihant Arden Logo">
    <div class="info">
      <h1>Arihant Arden Association of Apartment Owners</h1>
      <p>Plot No GH-07A, Sector 1, Greater Noida West</p>
      <p>Phone: +91 (0) 120 5145800 | Email: <a href="mailto:admin@arihantardenaoa.org">admin@arihantardenaoa.org</a></p>
    </div>
  </header>

  <nav>
    <a href="default.asp">Home</a>
    <a href="html_about.asp">About</a>
    <a href="html_gallery.asp">Gallery</a>
    <a href="html_Tender.asp">Tender</a>
<a href="slides.asp">Slides</a>
  </nav>

  <main>
    <div class="carousel">
      <div class="slides" id="slides">
        <div class="slide"><img src="ArihantArden1.jpg" alt="Event 1"></div>
        <div class="slide"><img src="ArihantArden2.jpg" alt="Event 2"></div>
        <div class="slide"><img src="ArihantArden3.jpg" alt="Event 3"></div>
      </div>
      <div class="carousel-buttons">
        <button onclick="prevSlide()">&#10094;</button>
        <button onclick="nextSlide()">&#10095;</button>
      </div>
    </div>
  </main>

  <script>
    let currentIndex = 0;
    const slides = document.getElementById("slides");

    function showSlide(index) {
      const totalSlides = slides.children.length;
      if (index >= totalSlides) currentIndex = 0;
      else if (index < 0) currentIndex = totalSlides - 1;
      else currentIndex = index;
      slides.style.transform = `translateX(-${currentIndex * 100}%)`;
    }

    function nextSlide() {
      showSlide(currentIndex + 1);
    }

    function prevSlide() {
      showSlide(currentIndex - 1);
    }

    // Auto-play
    setInterval(() => {
      nextSlide();
    }, 5000); // Change slide every 5 seconds
  </script>

</body>
</html>
