<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Arihant Arden AAO</title>
  <meta name="description" content="Arihant Arden AAO – Association of Apartment Owners, Greater Noida West"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">

  <style>
    :root {
      --primary: #2e7d32;
      --bg: #f1fdf3;
      --accent: #43a047;
      --white: #fff;
      --shadow: rgba(0, 0, 0, 0.1);
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Poppins', sans-serif;
      background: var(--bg);
      color: #333;
      line-height: 1.6;
    }

    header {
      background: var(--accent);
      color: var(--white);
      box-shadow: 0 4px 12px var(--shadow);
      padding: 1.5rem 2rem;
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      justify-content: space-between;
    }

    header img {
      height: 70px;
      margin-right: 1rem;
    }

    .info h1 {
      font-size: 1.6rem;
      margin-bottom: 0.2rem;
    }

    .info p, .info a {
      font-size: 0.95rem;
      color: #f9f9f9;
    }

    nav {
      background: var(--white);
      display: flex;
      justify-content: center;
      padding: 1rem 0;
      gap: 2rem;
      box-shadow: 0 2px 6px var(--shadow);
    }

    nav a {
      color: var(--primary);
      font-weight: 500;
      text-decoration: none;
      position: relative;
      transition: color 0.3s ease;
    }

    nav a::after {
      content: "";
      display: block;
      width: 0;
      height: 2px;
      background: var(--primary);
      transition: width 0.3s;
      margin-top: 5px;
    }

    nav a:hover {
      color: #000;
    }

    nav a:hover::after {
      width: 100%;
    }

    main {
      max-width: 1000px;
      margin: 2rem auto;
      padding: 0 1.2rem;
    }

    .event-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 2rem;
    }

    .card {
      background: var(--white);
      border-radius: 12px;
      box-shadow: 0 6px 20px var(--shadow);
      padding: 2rem;
      transition: 0.3s ease;
      text-align: center;
    }

    .card:hover {
      transform: scale(1.02);
    }

    .card h2 {
      color: var(--primary);
      margin-bottom: 1rem;
    }

    .card p {
      font-size: 1.05rem;
      margin-bottom: 1rem;
    }

    .card a {
      display: inline-block;
      background: var(--accent);
      color: white;
      text-decoration: none;
      padding: 0.6rem 1.2rem;
      border-radius: 6px;
      transition: background 0.3s;
      font-weight: 500;
    }

    .card a:hover {
      background: #2e7d32;
    }

    @media (max-width: 768px) {
      header {
        flex-direction: column;
        text-align: center;
      }

      nav {
        flex-direction: column;
        align-items: center;
        gap: 1rem;
      }

      .info h1 {
        font-size: 1.4rem;
      }
    }
  </style>
</head>

<body>
  <header>
    <img src="untitled.png" alt="Arihant Arden Logo" />
    <div class="info">
      <h1>Arihant Arden Association of Apartment Owners</h1>
      <p>Plot No GH‑07A, Sector 1, Greater Noida West</p>
      <p>📞 +91 120 5145800 • ✉️ <a href="mailto:admin@arihantardenaoa.org">admin@arihantardenaoa.org</a></p>
    </div>
  </header>

  <nav>
    <a href="default.asp">Home</a>
    <a href="html_about.asp">About</a>
    <a href="html_gallery.asp">Gallery</a>
    <a href="events.asp">Events</a>
    <a href="tender.html">Tenders</a>
  </nav>

  <main>
    <div class="event-grid">
      <!-- Teej -->
      <div class="card">
        <h2>Teej Celebration</h2>
        <p>Join us for traditional festivities, dance, and fun on <strong>26th July 2025</strong>.</p>
        <a href="https://docs.google.com/forms/d/e/1FAIpQLSdhsDMHGD75a4vtAioTWbs25ohPjhfNPRxj2t-G8ghZhNbeDw/viewform" target="_blank">Register Now</a>
      </div>

      <!-- Independence Day -->
      <div class="card">
        <h2>Independence Day</h2>
        <p>Celebrate 78 years of freedom with flag hoisting, performances, and sweets on <strong>15th August 2025</strong>.</p>
        <a href="#">Details Coming Soon</a>
      </div>

      <!-- Janmashtami -->
      <div class="card">
        <h2>Janmashtami Mahotsav</h2>
        <p>Enjoy cultural programs, matki phod, and bhajan sandhya on <strong>18th August 2025</strong>.</p>
        <a href="#">Details Coming Soon</a>
      </div>
    </div>
  </main>
</body>
</html>
