<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Tenders – Arihant Arden AOA</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">

  <style>
    :root {
      --primary-color: #2e7d32;
      --secondary-color: #81c784;
      --bg-gradient: linear-gradient(to right, #e8f5e9, #c8e6c9);
      --text-color: #2e2e2e;
    }

    body {
      margin: 0;
      font-family: 'Poppins', sans-serif;
      background: var(--bg-gradient);
      color: var(--text-color);
    }

    header {
      display: flex;
      align-items: center;
      justify-content: flex-start;
      padding: 30px 40px;
      background: linear-gradient(to right, #66bb6a, #43a047);
      color: #fff;
      flex-wrap: wrap;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    }

    header img {
      height: 80px;
      margin-right: 20px;
    }

    header .info h1 {
      margin: 0 0 10px;
      font-size: 28px;
    }

    header .info p {
      margin: 5px 0;
      font-size: 15px;
    }

    header .info a {
      color: #fff;
      text-decoration: underline;
    }

    nav {
      display: flex;
      justify-content: center;
      background: #ffffff;
      padding: 15px 20px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    }

    nav a {
      margin: 0 15px;
      text-decoration: none;
      color: var(--primary-color);
      font-weight: 500;
      transition: color 0.3s ease, transform 0.2s ease;
    }

    nav a:hover {
      color: #1b5e20;
      transform: translateY(-2px);
    }

    .container {
      max-width: 1000px;
      margin: 40px auto;
      padding: 20px;
      background-color: #ffffffdd;
      border-radius: 12px;
      box-shadow: 0 6px 18px rgba(0, 0, 0, 0.08);
    }

    .tender {
      margin-bottom: 35px;
      padding-bottom: 15px;
      border-bottom: 1px solid #ddd;
    }

    .tender h3 {
      font-size: 20px;
      color: var(--primary-color);
      margin-bottom: 10px;
    }

    .tender a {
      font-weight: 500;
      text-decoration: none;
      color: #1565c0;
      display: inline-block;
      margin-top: 5px;
    }

    .tender a:hover {
      text-decoration: underline;
    }

    .notice {
      background: #fff8e1;
      border-left: 6px solid #ffb300;
      padding: 15px 20px;
      border-radius: 8px;
      margin: 15px 0;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
    }

    footer {
      text-align: center;
      padding: 20px;
      background-color: #f4f4f4;
      color: #555;
      font-size: 14px;
      margin-top: 50px;
      box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.05);
    }

    @media (max-width: 768px) {
      header {
        flex-direction: column;
        text-align: center;
      }

      nav {
        flex-direction: column;
      }

      nav a {
        margin: 10px 0;
      }
    }
  </style>
</head>

<body>
  <header>
    <img src="untitled.png" alt="Arihant Arden Logo">
    <div class="info">
      <h1>Arihant Arden Association of Apartment Owners</h1>
      <p>Plot No GH-07A, Sector 1, Greater Noida West</p>
      <p>Phone: +91 (0) 120 5145800 | Email:
        <a href="mailto:admin@arihantardenaoa.org">admin@arihantardenaoa.org</a>
      </p>
    </div>
  </header>

  <nav>
    <a href="default.asp">Home</a>
    <a href="html_about.asp">About</a>
    <a href="html_gallery.asp">Gallery</a>
    <a href="tender.asp">Tender</a>
    <a href="achievements.asp">Achievements</a>
  </nav>

  <div class="container">

    <!-- CANCELLATION NOTICE -->
    <div class="tender">
      <h3>NOTICE OF TENDER CANCELLATION AND RE-TENDERING – Rooftop Solar System</h3>
      <p><strong>Tender No.:</strong> ARIHANT ARDEN/Rooftop Solar/2025-26/01</p>
      <p><strong>Date:</strong> 8th November 2025</p>

      <div class="notice">
        <p>The Board of Management, <strong>Arihant Arden Association of Apartment Owners (AAO)</strong>,
        hereby informs all concerned bidders and stakeholders that the above-referenced tender for 
        <em>“Design, Installation, Testing, and Commissioning of a 500 kVA Rooftop Solar System”</em>,
        originally published on <strong>23rd July 2025</strong>, is hereby <strong>cancelled</strong> due to administrative and technical review considerations.</p>

        <p>A revised tender (Re-Tender) will be issued shortly with updated technical specifications and timelines. 
        All interested and eligible bidders are requested to visit our official website 
        <a href="http://arihantardenaoa.org">www.arihantardenaoa.org</a> regularly for updates and release of the new tender document.</p>

        <p><strong>Refund Notice:</strong> The tender document fee and EMD (Earnest Money Deposit) received from participants 
        in the cancelled tender will be <strong>refunded in full within the next 15 working days</strong>, 
        <strong>if the respective bidder does not wish to participate in the upcoming re-tender.</strong></p>

        <p>Bidders intending to re-apply may request adjustment of their previously submitted EMD and document fee against the new tender.</p>
      </div>

      <p>📧 <strong>Email:</strong> <a href="mailto:Tender@arihantardenaoa.org">Tender@arihantardenaoa.org</a><br />
         📞 <strong>Phone:</strong> 9871291992 / 8130400550<br />
         ☎️ <strong>President Contact:</strong> 9899308933
      </p>

      <p><strong>By Order of the Board of Management</strong><br>
      <strong>Arihant Arden Association of Apartment Owners (AAO)</strong><br>
      <em>Date: 08-Nov-2025 Place: Greater Noida (West)</em></p>
    </div>

    <!-- ORIGINAL SOLAR TENDER -->
    <div class="tender">
      <h3>NOTICE INVITING TENDER – Rooftop Solar System</h3>
      <p><strong>Tender No.:</strong> ARIHANT ARDEN/Rooftop Solar/2025-26/01</p>
      <p><strong>Date:</strong> 23rd July 2025</p>
      <p>
        The Board of Management, Arihant Arden, GH-07A, Sector-1, Greater Noida (West), U.P – 201318,
        invites sealed tenders from eligible companies for the design, installation, testing, and commissioning
        of a 500 kVA Rooftop Solar System.
      </p>
      <p>
        The tender document is available at
        <a href="SolarTenderAA_NishithFinal.pdf" target="_blank">Solar System Tender document</a>. 
        Any corrigendum or time extension, if applicable, will be published on the same website.
      </p>

      <p><strong>Schedule:</strong></p>
      <ul style="margin-left: 20px;">
        <li><strong>Last Date for Submission of Bids:</strong> 4th September 2025, 6:00 PM</li>
        <li><strong>Opening of Tender:</strong> 6th September 2025, 12 PM</li>
        <li><strong>Venue:</strong> Iconic Club, 2nd Floor, Arihant Arden</li>
      </ul>

      <p><strong>Tender Fee and Deposits:</strong></p>
      <ul style="margin-left: 20px;">
        <li><strong>Document Fee:</strong> ₹5,000/-</li>
        <li><strong>Earnest Money Deposit (EMD):</strong> ₹5,00,000/- (Five Lakhs Only) <b>refundable</b></li>
      </ul>

      <p><strong>Account Details for Fee/EMD Payment:</strong></p>
      <ul style="margin-left: 20px;">
        <li><strong>Account Name:</strong> Arihant Arden Association of Apartment Owners</li>
        <li><strong>Account Number:</strong> 723801000065</li>
        <li><strong>Bank Name:</strong> ICICI Bank</li>
        <li><strong>IFSC Code:</strong> ICIC0007238</li>
        <li><strong>Branch:</strong> Paramount Emotions, Sector-1, Greater Noida West – 201306</li>
      </ul>

      <p style="margin-top: 10px; font-weight: 500; color: #c62828;">
        🔔 <strong>Note:</strong> Please share your GST number while submitting the Tender Fee for GST-related purposes.
      </p>

      <p>
        📧 <strong>Email:</strong> <a href="mailto:Tender@arihantardenaoa.org">Tender@arihantardenaoa.org</a><br />
        📞 <strong>Phone:</strong> 9871291992 / 8130400550<br />
        ☎️ <strong>President Contact:</strong> 9899308933
      </p>

      <p><strong>President</strong><br />AAO, Arihant Arden</p>
    </div>

    <!-- OLD SECURITY TENDERS -->
    <div class="tender">
      <h3>New Security Tender - Final Evaluation Result (Published: 09 June 2023)</h3>
      <a href="FinalTenderResult-ArihantArden.pdf" target="_blank">Final Evaluation Result (PDF)</a>
    </div>

    <div class="tender">
      <h3>New Security Tender - Technical Evaluation Result (Published: 06 June 2023)</h3>
      <a href="TechnicalEvaluationResult.pdf" target="_blank">Technical Evaluation Result (PDF)</a>
    </div>

    <div class="tender">
      <h3>New Security Tender Document (Published: 30 April 2023)</h3>
      <a href="SecurityServiceTenderDocument-AAAAO.pdf" target="_blank">Tender Document (Last Date: 15 May 2023)</a><br>
      <span>(Also available at Arihant Arden AAO Office)</span>
    </div>

    <div class="tender">
      <h3>New Security Tender Notice (Published: 24 April 2023)</h3>
      <a href="NewSecurityTenderNotice.pdf" target="_blank">Tender Notice (PDF)</a>
    </div>

    <div class="tender">
      <h3>Notice to Abort & Re-initiate Tender (Published: 20 April 2023)</h3>
      <a href="NewTenderProcessNotice.pdf" target="_blank">View Notice (PDF)</a>
    </div>

    <div class="tender">
      <h3>Corrigendum on Security Tender (Published: 22 March 2023)</h3>
      <a href="CorrigendumSecurityTender.pdf" target="_blank">Corrigendum Document (PDF)</a>
    </div>

    <div class="tender">
      <h3>Security Agency Tender (Bid Deadline: 31 March 2023, 6 PM)</h3>
      <a href="SecurityTenderNotice.pdf" target="_blank">Notice Inviting Tender (PDF)</a><br>
      <a href="RevisedSecurityTenderDocument22032023.pdf" target="_blank">Revised Tender Document (22 March 2023)</a><br>
      <span>(Also available at Arihant Arden AAO Office)</span>
    </div>
  </div>

  <footer>
    &copy; 2025 Arihant Arden AOA. All rights reserved.
  </footer>
</body>
</html>
